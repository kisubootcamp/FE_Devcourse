<script setup></script>
<template>
  <h1>Home View</h1>
</template>
<style scoped></style>
